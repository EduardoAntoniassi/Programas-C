#include <stdlib.h>
#include <stdio.h>
#include <math.h>
main() {
	
	int A;
	
	printf("Insira um valor: \n" ,A);
	scanf("%d" , &A);
	
	if (A >= 50){
	 printf("%d" ,A/2);
	
	} else if (A < 50){ 
	 printf("%d" ,A*2);
	}
	
	
	
	
}
