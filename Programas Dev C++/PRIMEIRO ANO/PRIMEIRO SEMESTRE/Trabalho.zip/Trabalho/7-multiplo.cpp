#include <stdlib.h>
#include <stdio.h>
#include <math.h>
main() {
	
    int A;
	
	printf("Insira um valor: \n" ,A);
	scanf("%d" ,&A);
	
	if (A % 3 == 0 ) {
		printf("%d eh multiplo de tres" ,A);
	
	} else {
		printf("%d nao eh multiplo de tres" ,A);
	}
	
	
	
}
