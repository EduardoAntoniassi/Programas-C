#include<stdio.h>
#include<stdlib.h>

struct Filial{
    char text[40];
    int code;
    int count;
    double sells;
};

int main(){
    FILE *file = fopen("vendas.txt", "r+");

    struct Filial filiais[4];

    int counter = 0;

    while(fgets(filiais[counter].text, 40, file) != NULL){
        filiais[counter].code = atoi(filiais[counter].text[0]);
        filiais[counter].count++;
        for (int i = 2; i < sizeof(filiais[counter].text); i++){
        }
        
        counter++;
    }

    fclose(file);

    return 0;
}