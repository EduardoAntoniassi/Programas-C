#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

struct Filial{
    char text[40];
    char name[40];
    char populationArray[40];
    int totalSells;
};

int main(){
    FILE *file = fopen("entrada.txt", "r+");
    FILE *file2 = fopen("saida.txt", "w+");

    struct Filial cities[10000];

    int counter = 0;

    while(fgets(cities[counter].text, 40, file) != NULL){
        counter++;
    }

    for(int i = 0; i < sizeof(cities); i++){
        
        bool isName = true;

        int counterNumber = 0;

        for(int j = 0; j < sizeof(cities[i].text); j++){
            if(cities[i].text[j] == ':'){
                isName = false;
                continue;
            }

            if(isName == true){
                cities[i].name[j] = cities[i].text[j];
            }else{
                cities[i].populationArray[counterNumber] = cities[i].text[j];
                counterNumber++;
            }
        }

    }

    for(int i = 0; i < sizeof(cities); i++){
        cities[i].totalSells = atoi(cities[i].populationArray);
    }

    int index = 0;

    for(int i = 0; i < sizeof(cities); i++){
        if(cities[i].totalSells > cities[index].totalSells){
            index = i;
        }
    }

    printf("Cidade mais populosa é: %s\n",cities[index].name);
    printf("Com essa populaçao: %s\n",cities[index].totalSells);

    fclose(file);
    fclose(file2);

    return 0;
}