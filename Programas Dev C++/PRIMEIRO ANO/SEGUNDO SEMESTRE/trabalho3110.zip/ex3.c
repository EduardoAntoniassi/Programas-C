#include<stdio.h>
#include<stdlib.h>

int main(){
    FILE *file = fopen("teste.txt", "r+");
    FILE *file2 = fopen("teste2.txt", "r+");

    if (file == NULL){
        printf("\n Erro na abertura do arquivo \n");
        exit(1);
    }

    if (file2 == NULL){
        printf("\n Erro na abertura do arquivo \n");
        exit(1);
    }

    FILE *newFile = fopen("teste3.txt","w+");

    char c;
    do
    {
        c = fgetc(file);
        fprintf(newFile,"%c",c);
    }while (c != EOF);

    do
    {
        c = fgetc(file2);
        fprintf(newFile,"%c",c);
    }while (c != EOF);

    fclose(file);
    fclose(file2);
}