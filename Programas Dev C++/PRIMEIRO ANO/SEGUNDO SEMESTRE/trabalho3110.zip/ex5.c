#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

struct Person{
    char text[40];
    char name[40];
    char yearArray[40];
    int year;
};

int main(){
    int year;

    printf("Qual o ano? \n");
    scanf("%i",&year);


    FILE *file = fopen("entrada.txt", "r+");
    FILE *file2 = fopen("saida.txt", "w+");

    struct Person persons[10000];

    int counter = 0;

    while(fgets(persons[counter].text, 40, file) != NULL){
        counter++;
    }

    for(int i = 0; i < (int) sizeof(persons); i++){
        
        bool isName = true;

        int counterNumber = 0;

        for(int j = 0; j < (int) sizeof(persons[i].text); j++){
            if(persons[i].text[j] == ':'){
                isName = false;
                continue;
            }

            if(isName == true){
                persons[i].name[j] = persons[i].text[j];
            }else{
                persons[i].yearArray[counterNumber] = persons[i].text[j];
                counterNumber++;
            }
        }

    }

    for(int i = 0; i < sizeof(persons); i++){
        persons[i].year = atoi(persons[i].yearArray);

        int age = year - persons[i].year;

        if(age < 18){
            fprintf(file2, "%s", "Menor de idade");
        }else if(age == 18){
            fprintf(file2, "%s", "Entrando na maioridade");
        }else if(age > 18){
            fprintf(file2, "%s", "Maior de idade");
        }
    }

    fclose(file);
    fclose(file2);

    return 0;
}