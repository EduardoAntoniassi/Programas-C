#include<stdio.h>
#include<stdlib.h>

int main(){
    FILE *arquivo;

    char charUser;

    printf("Digite um char: \n");
    scanf("%c",&charUser);

    __fpurge(stdin);

    arquivo = fopen("teste.txt", "r");

    if (arquivo == NULL){
        printf("\n Erro na abertura do arquivo \n");
        exit(1);
    }

    int counter = 0;
    char c;
    do
    {
        c = fgetc(arquivo);
        if(charUser == c){
            counter++;
        }
    }while (c != EOF);


    printf("Quantia que se repete: %d\n", counter);

    fclose(arquivo);
}