#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

bool contains(char vogais[], char c){
    for(int i = 0; i< sizeof(vogais); i++){
        if(vogais[i] == toupper(c)){
            return true;
        }
    }
    return false;
}

int main(){
    FILE *file = fopen("teste.txt", "r+");
    FILE *newFile = fopen("teste2.txt", "w+");

    char vogais[] = {'A','E','I','O','U'};

    __fpurge(stdin);

    if (file == NULL){
        printf("\n Erro na abertura do arquivo \n");
        exit(1);
    }

    int counter = 0;
    char c;
    do
    {
        c = fgetc(file);
        if(contains(vogais,c)){
            counter++;
            fprintf(newFile,"%c",'*');
        }else{
            fprintf(newFile,"%c",c);
        }
    }while (c != EOF);

    printf("Quantia substituida: %d\n", counter);

    fclose(file);
    fclose(newFile);
}